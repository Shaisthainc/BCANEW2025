import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

# Title and Description
st.title("Smoking Status Prediction Model")
st.write("Upload your dataset to analyze and predict smoking status.")

# File Uploader
uploaded_file = st.file_uploader("Upload CSV", type=["csv"])

if uploaded_file is not None:
    # Load Data
    data = pd.read_csv(uploaded_file)
    st.write("### Dataset Preview:")
    st.write(data.head())
    
    # Show dataset shape
    st.write(f"Dataset contains {data.shape[0]} rows and {data.shape[1]} columns.")
    
    # Data Analysis
    st.write("### Data Summary:")
    st.write(data.describe())
    st.write("### Missing Values:")
    st.write(data.isnull().sum())
    
    # Data Visualization
    st.write("### Data Visualization:")
    numeric_columns = data.select_dtypes(include=['number']).columns.tolist()
    if numeric_columns:
        selected_col = st.selectbox("Select column to visualize:", numeric_columns)
        fig, ax = plt.subplots()
        sns.histplot(data[selected_col], kde=True, ax=ax)
        st.pyplot(fig)
    else:
        st.write("No numeric columns available for visualization.")
    
    # Pre-processing
    st.write("### Data Preprocessing:")
    data = data.dropna()
    data = pd.get_dummies(data, drop_first=True)
    st.write("Processed Data Preview:")
    st.write(data.head())
    
    # Splitting data
    X = data.drop(columns=['smoking'])  # Assuming 'smoking' is the target column
    y = data['smoking']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Model Training
    st.write("### Model Training:")
    model = RandomForestClassifier()
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    
    # Model Evaluation
    accuracy = accuracy_score(y_test, y_pred)
    st.write(f"Model Accuracy: {accuracy:.2f}")
    st.write("### Classification Report:")
    st.text(classification_report(y_test, y_pred))
